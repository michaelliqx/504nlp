package us.codecraft.webmagic.pipeline;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @description: This is a Pipeline implemented with RabbitMQ
 * @author: Zhizhou Qiu
 * @create: 04-22-2019
 **/
public class RabbitPipeline implements Pipeline{
    ConnectionFactory connectionFactory;
    Connection connection;
    Channel channel;
    public RabbitPipeline(){
        try{
            this.connectionFactory = new ConnectionFactory();
            connectionFactory.setHost("127.0.0.1");
            this.connection = connectionFactory.newConnection();
            this.channel = connection.createChannel();
            channel.queueDeclare(QUEUE_NAME, true, false, false, null);
        } catch (IOException io){
            io.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    private static String QUEUE_NAME = "gutenberg";


    @Override
    public void process(ResultItems resultItems, Task task) {

        try{
            System.out.println("==============================");
            System.out.println("get page: " + resultItems.getRequest().getUrl());

            List<List<String>> content = new ArrayList<List<String>>();
            for (Map.Entry<String, Object> entry : resultItems.getAll().entrySet()) {
                String key = entry.getKey();
                List<String> list = (ArrayList<String>) entry.getValue();
                System.out.println("Key: " + entry.getKey() + ":\t" + "Value: " + list);
                for (String s : list){
                    System.out.println(" [X] Sent '" + s + "'");
                    channel.basicPublish("", QUEUE_NAME, null, s.getBytes("UTF-8"));
                }
            }
        } catch (IOException io) {
            io.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();
        }


    }
}

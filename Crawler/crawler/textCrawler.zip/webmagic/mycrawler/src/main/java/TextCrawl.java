import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.pipeline.ConsolePipeline;
import us.codecraft.webmagic.pipeline.FilePipeline;
import us.codecraft.webmagic.pipeline.RabbitPipeline;
import us.codecraft.webmagic.processor.PageProcessor;

import java.util.ArrayList;
import java.util.List;

/**
 * @description: This is a text crawler implementation
 * @author: Zhizhou Qiu
 * @create: 04-22-2019
 **/
public class TextCrawl implements PageProcessor {

    public static void main(String[] args){

        Spider.create(new TextCrawl())
                .addUrl("http://www.gutenberg.org/files/9/9-h/9-h.htm")
//                .addPipeline(new RabbitPipeline())   // this is a pipeline implemented with RabbitMQ
                .addPipeline(new ConsolePipeline())
//                .addPipeline(new FilePipeline("/Users/zhizhouqiu/Desktop/EC504/testUse/webmagic/data"))
                .thread(10)
                .run();
    }


    private Site site = Site.me().setCycleRetryTimes(5).setRetryTimes(5).setSleepTime(500).setTimeOut(3 * 60 * 1000)
            .setUserAgent("Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0")
            .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .addHeader("Accept-Language", "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3")
            .setCharset("UTF-8");
    private static final String URL_TEST = "http://www.gutenberg.org/0/3/3-h/3-h.htm";
    private static final String URL_POST = "";

    @Override
    public void process(Page page) {

        page.addTargetRequests(process());
        //page.addTargetRequests(page.getHtml().links().regex(URL_POST).all());
        page.putField("content",page.getHtml().xpath("//p/text()").all());
    }

    @Override
    public Site getSite() {
        return site;
    }

    private static List<String> process(){
        List<String> urls = new ArrayList<String>();
        StringBuilder sb = new StringBuilder();
        sb.append("http://www.gutenberg.org/0");
        int length = sb.length();
        for (int i = 10; i < 2000; i++){
            sb.append("/"+i);
            String s = "/"+i+"-h/"+i+"-h.htm";
            sb.append(s);
            urls.add(sb.toString());
            sb.setLength(length);
        }
        return urls;
    }
}


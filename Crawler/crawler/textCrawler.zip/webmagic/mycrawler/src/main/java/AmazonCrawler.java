import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.downloader.HttpClientDownloader;
import us.codecraft.webmagic.pipeline.ConsolePipeline;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.proxy.Proxy;
import us.codecraft.webmagic.proxy.SimpleProxyProvider;

/**
 * @description: This is a crawler to crawler commodity information
 * @author: Zhizhou Qiu
 * @create: 04-22-2019
 **/
public class AmazonCrawler implements PageProcessor {
    private Site site = Site.me().setCycleRetryTimes(5).setRetryTimes(5).setSleepTime(500).setTimeOut(3 * 60 * 1000)
            .setUserAgent("Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0")
            .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .addHeader("Accept-Language", "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3")
            .setCharset("UTF-8");
    private static final String URL_TEST = "https://www.amazon.com/\\w+/\\w+/\\w+/\\w+";
    private static final String URL_POST = "https://www.amazon.com/\\w+/\\w+";

    @Override
    public void process(Page page) {
        page.addTargetRequests(page.getHtml().links().regex(URL_TEST).all());
        page.addTargetRequests(page.getHtml().links().regex(URL_POST).all());
        page.putField("content",page.getHtml().smartContent());
    }

    @Override
    public Site getSite() {
        return site;
    }

    public static void main(String[] args){
        HttpClientDownloader httpClientDownloader = new HttpClientDownloader();
        httpClientDownloader.setProxyProvider(SimpleProxyProvider.from(new Proxy("1.192.242.120",9999,"username","password")));
        Spider.create(new AmazonCrawler())
                .addUrl("https://www.amazon.com/s/ref=nb_sb_noss?field-keywords=nicon")
                .addPipeline(new ConsolePipeline())
                .setDownloader(httpClientDownloader)
                .thread(5)
                .run();
    }
}
